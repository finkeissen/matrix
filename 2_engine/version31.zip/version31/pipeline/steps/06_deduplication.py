"""steps/06_deduplication.py — Step 06: Three-level deduplication.

Deterministic step — no LLM call.

Reads:  step_input["validated_problems"]   (from 05_validation via step_chain)
Reads:  data/registry/problems/index.json  (known hashes — optional)
Writes: intermediate/06_deduplication.json
Writes: rejected/duplicates.json
"""
from __future__ import annotations

import json
from pathlib import Path

from ..dedup import run_full_dedup
from ..logging_setup import get_logger

logger = get_logger(__name__)


def run(ctx, step_input: dict, config, prompt_loader) -> dict:
    step_name = "06_deduplication"
    domain: str = step_input["domain"]
    problems: list = step_input.get("validated_problems", [])

    if not problems:
        raise ValueError(f"{step_name}: validated_problems is empty — nothing to deduplicate")

    known_hashes, known_normalized = _load_known(config)

    import os
    semantic_enabled = os.getenv("SEMANTIC_DEDUP_ENABLED", "false").lower() == "true"
    result = run_full_dedup(problems, known_hashes, known_normalized, semantic_enabled)

    int_dir = ctx.intermediate_dir()
    rej_dir = ctx.rejected_dir()

    out_path = int_dir / f"{step_name}.json"
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    rej_path = rej_dir / "duplicates.json"
    duplicates = result["rejected_exact"] + result["rejected_normalized"] + result["rejected_semantic"]
    rej_path.write_text(json.dumps(duplicates, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "data": result["accepted"],
        "output_path": str(out_path),
        "counts": result["counts"],
    }


def _load_known(config) -> tuple[set, set]:
    index_path = config.registry_dir / "problems" / "index.json"
    if not index_path.exists():
        return set(), set()
    with open(index_path, encoding="utf-8") as f:
        index = json.load(f)
    return set(index.get("hashes", [])), set(index.get("normalized", []))
