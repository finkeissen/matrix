from __future__ import annotations

import json
from datetime import datetime, timezone


def run(ctx, domain, config, prompt_loader):
    cats_path = ctx.intermediate_dir() / "03_categories.json"

    if cats_path.exists():
        payload = json.loads(cats_path.read_text(encoding="utf-8"))

        if isinstance(payload, dict):
            raw_categories = payload.get("categories", [])
        elif isinstance(payload, list):
            raw_categories = payload
        else:
            raw_categories = []
    else:
        raw_categories = [domain]

    categories = []
    for item in raw_categories:
        if isinstance(item, str) and item.strip():
            categories.append(item.strip())
        elif isinstance(item, dict):
            category = item.get("category")
            if isinstance(category, str) and category.strip():
                categories.append(category.strip())

    if not categories:
        categories = [domain]

    problems = []
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    for idx, cat in enumerate(categories, start=1):
        problems.append(
            {
                "problem_id": f"ap_{idx:06d}",
                "title": f"{cat.replace('_', ' ').title()} scenario {idx}",
                "problem_statement": (
                    f"Analyze a representative {domain} problem in category {cat} "
                    f"and determine the governing result with a justified solution path."
                ),
                "category": cat,
                "difficulty": "medium" if idx % 3 else "hard",
                "source_run_id": ctx.manifest.run_id,
                "created_at": now,
            }
        )

    out = ctx.intermediate_dir() / "04_problem_generation.json"
    out.write_text(json.dumps(problems, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "data": problems,
        "output_path": str(out),
        "counts": {"generated": len(problems)},
    }
