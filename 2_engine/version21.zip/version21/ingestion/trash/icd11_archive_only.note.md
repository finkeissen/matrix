# Archive-only decision for ICD-11

Die Datei `icd11_enriched_ultra_flat.jsonl.zip` wurde unter `archive/imports/` und `imports/` abgelegt,
aber nicht in globale produktive Assets transformiert. Grund: stark domänenspezifischer medizinischer Korpus,
für allgemeine Pipeline-Läufe ohne medizinische Domain nicht geeignet.
