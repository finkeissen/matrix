Hier liegen bewusst nicht freigegebene oder nur archivierte Inhalte.

- `icd11_archive_only.note.md`: ICD-11 wurde archiviert, aber nicht in globale Seeds/Rules übernommen, weil es domänenspezifisch ist.
- `partials_review_warnings.md`: Hinweise, warum partials nur reviewed statt approved sind.
