# Review warnings for partial seed candidates

- Anzahl Dateien: 650
- Sprachhinweis: {'other': 19, 'de': 631}
- Enthält gemischte Sprachen und heterogene Domains.
- Daher nicht als approved Seed-Library freigegeben.
