# Translation errors are locally contained

**Error Group:** Translation / Mapping Errors

## Description
This document records a recurring conceptual error observed across institutions,
technical systems, and large-scale coordination.

The error consists in assuming:

> Translation errors are locally contained

## Why This Is a Problem
This assumption collapses adversarial dynamics, coordination constraints,
or translation boundaries that must remain explicit in formally bounded systems.

## Typical Consequences
- Systematic vulnerability to gaming or manipulation
- Silent scope drift across representations
- Misalignment between policy, measurement, and real-world behavior

## Status
This file is part of `0.legacy/`.
It carries **no normative or epistemic authority**.
It serves solely as diagnostic raw material.
