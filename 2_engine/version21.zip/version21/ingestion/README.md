# Information Ingestion Bundle

Dieses Bundle wendet den vereinbarten Ingestion-Standard direkt auf die bereitgestellten Dateien an.

## Was enthalten ist

- `archive/imports/`: unveränderte Original-ZIPs
- `imports/`: entpackte Arbeitskopien der Quellen
- `rules/`: normalisierte, wiederverwendbare Regel- und Fall-Assets
- `seeds/`: normalisierte Seed-Kandidaten und wiederverwendbare Pattern-Listen
- `taxonomy/`: strukturierte Familien / Kategorien für spätere Domain-Mappings
- `manifests/`: Status, Herkunft und Entscheidungsgrund pro Asset
- `schemas/`: JSON-Schemas für produktive Assets und Manifests
- `trash/`: bewusst nicht produktiv übernommene oder nur archivierte Inhalte

## Entscheidungslogik für diese konkrete Umwandlung

- `contradictions.zip` → als globale Regelbibliothek und Taxonomie übernommen
- `cases.zip` → als Case-Corpus + Gate-Regeln übernommen
- `meta.zip`, `structural.zip`, `atomic.zip` → als globale Seed-/Pattern-Bibliothek übernommen
- `partials.zip` → nur als *candidate input* übernommen, nicht direkt produktiv freigegeben
- `icd11_enriched_ultra_flat.jsonl.zip` → archiviert, aber für allgemeine Pipeline-Nutzung nicht freigegeben (domänenspezifisch)

## Reuse

Produktiv wiederverwendbar sind nur Assets mit `status: approved`.
Rohdaten unter `archive/` und `imports/` werden nicht direkt von der Pipeline konsumiert.
