# pipeline.eval

Dieses Paket ist **explizit außerhalb der produktiven Pipeline** gedacht.

Ziele:

1. **Step-Suitability prüfen**  
   Ermitteln, für welche Steps ein geladenes LLM grundsätzlich geeignet ist.

2. **Parameter kalibrieren**  
   Für geeignete Steps mehrere Parameterkombinationen testen und die beste Kombination
   auf Basis von Run-Metriken und Downstream-Erfolg ermitteln.

## Wichtige Architekturentscheidung

Diese Skripte gehören **nicht** in `tests/`, weil sie:

- langsam sein können,
- externe LLM-Aufrufe machen,
- nicht deterministisch sind,
- experimentellen Charakter haben.

`tests/` sollte nur schnelle, deterministische Prüfungen enthalten.

## Annahmen

Die Skripte starten die Pipeline **separat per Subprocess** über einen frei definierbaren Command-Template-String,
z. B.:

```bash
python -m pipeline.cli run --domain {domain}
```

Dabei setzen die Skripte zusätzlich Environment-Variablen wie:

- `LLM_TEMPERATURE`
- `LLM_TOP_P`
- `LLM_MAX_TOKENS`
- `LLM_EVAL_STEP`

Falls eure Pipeline oder euer LLM-Client andere Namen erwartet, müsst ihr diese Zuordnung
im Adapter bzw. im Aufruf anpassen.

## Typischer Ablauf

### 1. Suitability prüfen

```bash
python -m pipeline.eval.evaluate_step_suitability   --domain thermodynamics   --model qwen2.5-72b   --steps 01_scope 02_seed_expansion 03_categories 04_problem_generation   --run-cmd "python -m pipeline.cli run --domain {domain}"
```

### 2. Parameter kalibrieren

```bash
python -m pipeline.eval.calibrate_llm_params   --domain thermodynamics   --model qwen2.5-72b   --step 04_problem_generation   --run-cmd "python -m pipeline.cli run --domain {domain}"
```

## Output

Die Skripte schreiben Berichte nach:

- `pipeline/eval/reports/`

und können zusätzlich Profile aktualisieren:

- `pipeline/eval/profiles/calibrated_profiles.json`

## Grenzen

Diese Version ist bewusst **ein externer Eval-Runner**, kein tiefer Eingriff in eure produktive Pipeline.
Sie kann:

- Runs anstoßen
- Runs bewerten
- Empfehlungen erzeugen

Sie kann nicht garantieren, dass step-spezifische Parameter wirklich angewendet werden,
wenn die produktive LLM-Anbindung diese Variablen noch nicht verwendet.
