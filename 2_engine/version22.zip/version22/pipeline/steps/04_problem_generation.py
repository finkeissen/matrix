from __future__ import annotations

import json
import os
from datetime import datetime, timezone


PROBLEM_STYLES = [
    {
        "verb": "analyze",
        "focus": "the governing physical principles",
        "goal": "determine the correct result with a justified reasoning chain",
    },
    {
        "verb": "derive",
        "focus": "the relevant thermodynamic relationship",
        "goal": "derive the key result step by step and justify all assumptions",
    },
    {
        "verb": "compare",
        "focus": "two plausible system behaviors",
        "goal": "compare the alternatives and identify which outcome is physically consistent",
    },
    {
        "verb": "estimate",
        "focus": "the dominant order-of-magnitude behavior",
        "goal": "estimate the expected result and explain why smaller effects can be neglected",
    },
    {
        "verb": "predict",
        "focus": "the response of the system under changed conditions",
        "goal": "predict the new outcome and justify the directional effect",
    },
    {
        "verb": "explain",
        "focus": "an apparently counterintuitive observation",
        "goal": "explain the observation using a coherent thermodynamic argument",
    },
    {
        "verb": "evaluate",
        "focus": "whether a proposed interpretation is valid",
        "goal": "evaluate the interpretation and identify the decisive criterion",
    },
    {
        "verb": "identify",
        "focus": "the limiting constraint in the scenario",
        "goal": "identify the bottleneck and explain its consequence for the final result",
    },
]

SCENARIO_VARIANTS = [
    "idealized closed-system conditions",
    "a quasi-static process setting",
    "a practical engineering setup",
    "a limiting-case approximation",
    "a measurement-oriented setup",
    "a comparison between reversible and irreversible behavior",
    "a parameter-variation setting",
    "a boundary-condition stress test",
]

DIFFICULTY_SEQUENCE = [
    "easy",
    "medium",
    "medium",
    "hard",
    "medium",
    "hard",
    "easy",
    "expert",
]


def _normalize_categories(raw_categories) -> list[str]:
    categories: list[str] = []

    for item in raw_categories:
        if isinstance(item, str) and item.strip():
            categories.append(item.strip())
        elif isinstance(item, dict):
            category = item.get("category")
            if isinstance(category, str) and category.strip():
                categories.append(category.strip())

    return categories


def _build_problem(domain: str, category: str, idx: int, variant_idx: int, run_id: str, now: str) -> dict:
    style = PROBLEM_STYLES[variant_idx % len(PROBLEM_STYLES)]
    scenario = SCENARIO_VARIANTS[(idx + variant_idx) % len(SCENARIO_VARIANTS)]
    difficulty = DIFFICULTY_SEQUENCE[(idx - 1) % len(DIFFICULTY_SEQUENCE)]

    category_label = category.replace("_", " ").title()
    title_prefix = style["verb"].title()

    title = f"{title_prefix} {category_label} case {idx}"

    problem_statement = (
        f"In the domain of {domain}, consider a {scenario} problem in the category {category}. "
        f"The task is to {style['verb']} {style['focus']} and {style['goal']}. "
        f"The solution should clearly state the assumptions, identify the relevant quantities, "
        f"and distinguish the dominant mechanism from secondary effects."
    )

    return {
        "problem_id": f"ap_{idx:06d}",
        "title": title,
        "problem_statement": problem_statement,
        "category": category,
        "difficulty": difficulty,
        "source_run_id": run_id,
        "created_at": now,
        "tags": [
            domain,
            category,
            style["verb"],
            scenario.replace(" ", "_"),
        ],
        "content_state": "candidate",
    }


def run(ctx, domain, config, prompt_loader):
    cats_path = ctx.intermediate_dir() / "03_categories.json"

    if cats_path.exists():
        payload = json.loads(cats_path.read_text(encoding="utf-8"))

        if isinstance(payload, dict):
            raw_categories = payload.get("categories", [])
        elif isinstance(payload, list):
            raw_categories = payload
        else:
            raw_categories = []
    else:
        raw_categories = [domain]

    categories = _normalize_categories(raw_categories)

    if not categories:
        categories = [domain]

    eval_mode = os.getenv("PIPELINE_EVAL_MODE", "0") == "1"

    if eval_mode:
        problems_per_category = int(os.getenv("PROBLEMS_PER_CATEGORY", "10"))
    else:
        problems_per_category = 1

    problems = []
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    idx = 1

    for cat in categories:
        for variant_idx in range(problems_per_category):
            problems.append(
                _build_problem(
                    domain=domain,
                    category=cat,
                    idx=idx,
                    variant_idx=variant_idx,
                    run_id=ctx.manifest.run_id,
                    now=now,
                )
            )
            idx += 1

    out = ctx.intermediate_dir() / "04_problem_generation.json"
    out.write_text(json.dumps(problems, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "data": problems,
        "output_path": str(out),
        "counts": {"generated": len(problems)},
    }
