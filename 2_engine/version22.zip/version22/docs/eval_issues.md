# LLM Pipeline – Evaluation Issues

Dieses Dokument dient als **Arbeitslog für Probleme, Beobachtungen und Entscheidungen**
bei der Evaluation der LLM-Pipeline.

Ziel:

- Probleme nachvollziehbar dokumentieren
- Ursachen analysieren
- Fixes und Entscheidungen festhalten
- spätere Parameter- und Modellentscheidungen begründen

Dieses Dokument ist **kein Bugtracker**, sondern ein technisches Arbeitsprotokoll.

---

# Issue 001 — Hohe Duplicate-Rate in `04_problem_generation`

## Status
open

## Datum
2026-03-08

## Kontext

Evaluation über:


pipeline.eval.evaluate_step_suitability


Modell:


qwen2.5-72b


Domain:


thermodynamics


Eval-Mode:


PIPELINE_EVAL_MODE=1
PROBLEMS_PER_CATEGORY=20


---

## Beobachtung

Eval-Run Ergebnis:


generated: 60
accepted: 3
duplicates: 57
acceptance_rate: 0.05
score: 0.4325


Interpretation:


95 % der generierten Probleme werden als Duplikate erkannt.


Der Step wird vom Eval-System als **nicht geeignet** bewertet.

---

## Betroffene Komponenten


pipeline/steps/04_problem_generation.py
pipeline/steps/06_deduplication.py
pipeline/eval/scoring.py


---

## Vermutete Ursache

Die aktuelle Implementierung von `04_problem_generation` nutzt ein
sehr starres Template.

Beispiel:


"{category} scenario {idx}"


Der Problemtext ist nahezu identisch:


Analyze a representative {domain} problem in category {cat}
and determine the governing result with a justified solution path.


Dadurch entstehen viele strukturell identische Probleme.

Die Deduplication erkennt diese als Duplikate.

---

## Bewertung

Das Problem liegt **primär in der Generierungslogik**, nicht in den LLM-Parametern.

Eine Parameterkalibrierung ist erst sinnvoll, wenn der Step
ausreichend Varianz erzeugt.

---

## Nächste Schritte

### Schritt 1 — Generierungslogik verbessern

`04_problem_generation` sollte:

- mehrere Problemtypen erzeugen
- unterschiedliche Aufgabenformen verwenden
- unterschiedliche Lösungswege erzwingen

Beispiele:


derive
predict
compare
explain
estimate
analyze


---

### Schritt 2 — Kleine Eval-Stichprobe

Eval mit kleiner Stichprobe:


categories: 3
problems_per_category: 5
total: 15


Ziel:

- Duplicate-Rate beobachten
- Acceptance-Rate prüfen
- Problemdiversität prüfen

---

### Schritt 3 — Parameteroptimierung

Erst nach erfolgreicher Diversifizierung.

Zu testende Bereiche:


temperature: 0.2 / 0.4 / 0.6
top_p: 0.85 / 0.92 / 0.97


---

# Issue 002 — Eval-Sample zu klein

## Status
resolved

## Beschreibung

Ursprünglich erzeugte `04_problem_generation` nur:


3 Probleme


Dadurch war die Evaluation nicht aussagekräftig.

Alle Parameterprofile hatten identische Scores.

---

## Lösung

Ein **Eval-Mode** wurde eingeführt.

Datei:


pipeline/steps/04_problem_generation.py


Neue Variablen:


PIPELINE_EVAL_MODE=1
PROBLEMS_PER_CATEGORY=10


Beispiel:


PIPELINE_EVAL_MODE=1 PROBLEMS_PER_CATEGORY=20 python -m pipeline.cli run --domain thermodynamics


---

# Offene Fragen

1. Soll `04_problem_generation` vollständig LLM-basiert generieren?
2. Wie wird Problemdiversität gemessen?
3. Soll Deduplication stärker semantisch arbeiten?

---

# Nächster Arbeitsschritt

Diversifizierung von 04_problem_generation implementieren


