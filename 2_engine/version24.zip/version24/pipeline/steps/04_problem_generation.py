from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from hashlib import sha1
from typing import Any


PROBLEM_STYLES = [
    {
        "verb": "analyze",
        "title": "Analyze",
        "task": "determine the governing physical principle",
        "deliverable": "justify the final result with a concise reasoning chain",
    },
    {
        "verb": "derive",
        "title": "Derive",
        "task": "derive the relevant relationship from first principles",
        "deliverable": "state each assumption explicitly and show the critical steps",
    },
    {
        "verb": "compare",
        "title": "Compare",
        "task": "contrast two plausible system behaviors",
        "deliverable": "identify which interpretation is physically consistent and why",
    },
    {
        "verb": "estimate",
        "title": "Estimate",
        "task": "estimate the dominant order-of-magnitude behavior",
        "deliverable": "explain why secondary effects can be neglected",
    },
    {
        "verb": "predict",
        "title": "Predict",
        "task": "predict the system response after a controlled change",
        "deliverable": "explain the direction and scale of the change",
    },
    {
        "verb": "explain",
        "title": "Explain",
        "task": "explain an apparently counterintuitive observation",
        "deliverable": "resolve the tension with a coherent domain argument",
    },
    {
        "verb": "evaluate",
        "title": "Evaluate",
        "task": "evaluate whether a proposed interpretation is valid",
        "deliverable": "identify the decisive criterion and defend the conclusion",
    },
    {
        "verb": "identify",
        "title": "Identify",
        "task": "identify the limiting constraint in the scenario",
        "deliverable": "show how the bottleneck controls the final outcome",
    },
]

SCENARIO_VARIANTS = [
    "idealized closed-system conditions",
    "a quasi-static process setting",
    "a practical engineering setup",
    "a limiting-case approximation",
    "a measurement-oriented investigation",
    "a reversible-versus-irreversible comparison",
    "a parameter-sweep experiment",
    "a boundary-condition stress test",
]

EVIDENCE_REQUIREMENTS = [
    "State the governing variables before drawing a conclusion.",
    "Name the assumption that matters most for the answer.",
    "Separate the dominant effect from secondary corrections.",
    "Include the physical consistency check that validates the result.",
    "Point out which quantity sets the scale of the outcome.",
    "Use a single argument structure from setup to conclusion.",
]

DIFFICULTY_SEQUENCE = ["easy", "medium", "medium", "hard", "medium", "hard", "easy", "expert"]

STATEMENT_PATTERNS = [
    "In {domain}, consider {scenario} for the category {category_label}. The task is to {task}. {evidence} The response should {deliverable}.",
    "A {domain} team is reviewing {category_label} under {scenario}. Ask the solver to {task}. {evidence} The final answer should {deliverable}.",
    "Construct a {scenario} case in {domain} focused on {category_label}. The solver must {task}. {evidence} The write-up should {deliverable}.",
    "Within {domain}, frame {category_label} as {scenario}. Require the solver to {task}. {evidence} The solution should {deliverable}.",
]


def _normalize_categories(raw_categories: list[Any]) -> list[str]:
    categories: list[str] = []

    for item in raw_categories:
        if isinstance(item, str) and item.strip():
            categories.append(item.strip())
        elif isinstance(item, dict):
            category = item.get("category")
            if isinstance(category, str) and category.strip():
                categories.append(category.strip())

    return categories


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower())
    return slug.strip("_") or "item"


def _read_positive_int_env(name: str, default: int) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"Environment variable {name} must be an integer, got {raw!r}") from exc
    if value <= 0:
        raise ValueError(f"Environment variable {name} must be greater than zero, got {value}")
    return value


def _build_problem(domain: str, category: str, index: int, variant_index: int, run_id: str, now: str) -> dict[str, Any]:
    style = PROBLEM_STYLES[variant_index % len(PROBLEM_STYLES)]
    scenario = SCENARIO_VARIANTS[(index + variant_index) % len(SCENARIO_VARIANTS)]
    difficulty = DIFFICULTY_SEQUENCE[(index - 1) % len(DIFFICULTY_SEQUENCE)]
    evidence = EVIDENCE_REQUIREMENTS[(index + 2 * variant_index) % len(EVIDENCE_REQUIREMENTS)]
    pattern = STATEMENT_PATTERNS[(index + variant_index) % len(STATEMENT_PATTERNS)]

    category_label = category.replace("_", " ").title()
    category_slug = _slugify(category)
    title = f"{style['title']} {category_label} case {variant_index + 1}"
    statement = pattern.format(
        domain=domain,
        scenario=scenario,
        category_label=category_label,
        task=style["task"],
        evidence=evidence,
        deliverable=style["deliverable"],
    )

    problem_key = f"{run_id}:{category_slug}:{variant_index + 1}:{style['verb']}:{scenario}"
    problem_suffix = sha1(problem_key.encode("utf-8")).hexdigest()[:10]

    return {
        "problem_id": f"ap_{category_slug}_{variant_index + 1:02d}_{problem_suffix}",
        "title": title,
        "problem_statement": statement,
        "category": category,
        "difficulty": difficulty,
        "source_run_id": run_id,
        "created_at": now,
        "tags": [
            domain,
            category,
            style["verb"],
            _slugify(scenario),
            difficulty,
        ],
        "content_state": "candidate",
    }


def run(ctx, domain, config, prompt_loader):
    categories_path = ctx.intermediate_dir() / "03_categories.json"

    if categories_path.exists():
        payload = json.loads(categories_path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            raw_categories = payload.get("categories", [])
        elif isinstance(payload, list):
            raw_categories = payload
        else:
            raw_categories = []
    else:
        raw_categories = [domain]

    categories = _normalize_categories(raw_categories) or [domain]

    eval_mode = os.getenv("PIPELINE_EVAL_MODE", "0") == "1"
    problems_per_category = _read_positive_int_env("PROBLEMS_PER_CATEGORY", 10 if eval_mode else 1)

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    problems: list[dict[str, Any]] = []

    for category_index, category in enumerate(categories, start=1):
        for variant_index in range(problems_per_category):
            problems.append(
                _build_problem(
                    domain=domain,
                    category=category,
                    index=category_index,
                    variant_index=variant_index,
                    run_id=ctx.manifest.run_id,
                    now=now,
                )
            )

    output_path = ctx.intermediate_dir() / "04_problem_generation.json"
    output_path.write_text(json.dumps(problems, indent=2, ensure_ascii=False), encoding="utf-8")

    return {
        "data": problems,
        "output_path": str(output_path),
        "counts": {
            "generated": len(problems),
            "categories": len(categories),
            "problems_per_category": problems_per_category,
        },
    }
